# Camel K Traits

In this section you will find examples about fine tuning your `Integration` using `trait` capability. Have a look at each directory containing example for the available traits.
