# Camel K JVM Trait

In this section you will find examples about fine tuning your `Integration` using **JVM** `trait` capability.